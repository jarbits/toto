<input type="hidden" name="<?php echo e($name, false); ?>" value="<?php echo e($value, false); ?>" class="<?php echo e($class, false); ?>" <?php echo $attributes; ?> />
