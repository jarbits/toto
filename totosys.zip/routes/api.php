<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group([
    'middleware' => ['api', 'cors'],
], function ($router) {
    Route::get('/get-post-num', 'APIController@getPostNum');
    Route::get('/get-resp-num', 'APIController@getRespNum');
    Route::get('/get-low-score-num', 'APIController@getLScoreNum');
    Route::get('/get-q1-rate', 'APIController@getQ1Rate');
    Route::get('/get-q1-five-rate', 'APIController@getQ1FiveRate');
    Route::get('/get-q13-part-rate', 'APIController@getQ13PartRate');
    Route::get('/get-q13-part-nps', 'APIController@getQ13PartNPS');
});