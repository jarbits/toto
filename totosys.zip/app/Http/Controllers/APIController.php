<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\RawSurvey;

class APIController extends Controller
{
    /**
     * 取得發送數
     * endpoint: /api/get-post-num?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getPostNum(Request $req)
    {
        $RawSurvey = RawSurvey::where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        return [count($RawSurvey)];
    }

    /**
     * 取得回覆數
     * endpoint: /api/get-resp-num?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getRespNum(Request $req)
    {
        $RawData = RawSurvey::where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        return [count($RawData)];
    }

    /**
     * 取得低分數量
     * endpoint: /api/get-low-score-num?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getLScoreNum(Request $req)
    {
        $LowScore = RawSurvey::where("cklow_score", "like", "%Q1%")
                              ->orWhere("cklow_score", "like", "%Q2%")
                              ->orWhere("cklow_score", "like", "%Q3%")
                              ->orWhere("cklow_score", "like", "%Q5%")
                              ->orWhere("cklow_score", "like", "%Q9%")
                              ->orWhere("cklow_score", "like", "%Q10%")
                              ->orWhere("cklow_score", "like", "%Q11%")
                              ->orWhere("cklow_score", "like", "%Q12%")
                              ->orWhere("cklow_score", "like", "%Q13%")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();                          

        return [count($LowScore)];
    }

    /**
     * 取得滿意度(Q1)百分比
     * endpoint: /api/get-q1-rate?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getQ1Rate(Request $req)
    {
        $Q1s = RawSurvey::where("q1", ">=", "4")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();
        $Q1Num = count($Q1s);

        $RawSurvey = RawSurvey::all();
        $RawSurveyNum = count($RawSurvey);

        $Q1Rate = $Q1Num/$RawSurveyNum;
                                   
        return [$Q1Rate];
    }

    /**
     * 取得滿意度(Q1)為5分的百分比
     * endpoint: /api/get-q1-five-rate?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getQ1FiveRate(Request $req)
    {
        $Q1s = RawSurvey::where("q1", "=", "5")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();
        $Q1Num = count($Q1s);

        $RawSurvey = RawSurvey::all();
        $RawSurveyNum = count($RawSurvey);
        
        $Q1Rate = $Q1Num/$RawSurveyNum;
                                   
        return [$Q1Rate];
    }

    /**
     * 取得Q13計算該題目分數各項資料占筆的平均0-6,7-8,9-10
     * endpoint: /api/get-q13-part-rate?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getQ13PartRate(Request $req)
    {
        $p0_6 = RawSurvey::where("q13", ">=", "0")
                              ->where("q13", "<=", "6")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        $p7_8 = RawSurvey::where("q13", ">=", "7")
                              ->where("q13", "<=", "8")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        $p9_10 = RawSurvey::where("q13", ">=", "9")
                              ->where("q13", "<=", "10")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        $RawSurvey = RawSurvey::all();
        $RawSurveyNum = count($RawSurvey);

        $data = [
            'rate0_6' => count($p0_6)/$RawSurveyNum,
            'rate7_8' => count($p7_8)/$RawSurveyNum,
            'rate9_10' => count($p9_10)/$RawSurveyNum
        ];
                                   
        return [$data];
    }

    /**
     * 取得Q13計算該題目[9-10]分數占比-[0-6]分數占比後得出的數值為NPS
     * endpoint: /api/get-q13-part-nps?StartTime=2022-02-11&EndTime=2022-02-22
     * parameter
     * 1. StartTime
     * 2. EndTime
     */
    public function getQ13PartNPS(Request $req)
    {
        $p0_6 = RawSurvey::where("q13", ">=", "0")
                              ->where("q13", "<=", "6")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        $p9_10 = RawSurvey::where("q13", ">=", "9")
                              ->where("q13", "<=", "10")
                              ->where("start_time", ">=", $req->StartTime)
                              ->where("end_time", "<", $req->EndTime)
                              ->get();

        $RawSurvey = RawSurvey::all();
        $RawSurveyNum = count($RawSurvey);

        $data = [
            'rate0_6' => count($p0_6)/$RawSurveyNum,
            'rate9_10' => count($p9_10)/$RawSurveyNum,
            'NPS' => count($p0_6)/$RawSurveyNum - count($p9_10)/$RawSurveyNum
        ];

        return [$data];
    }
}
