<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RawSurvey extends Model
{
    protected $table = 'rawsurvey';
    protected $guarded = [];
}
